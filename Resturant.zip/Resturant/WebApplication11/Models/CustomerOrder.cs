﻿namespace WebApplication11.Models
{
    public class CustomerOrder
    {
        public int ID {get; set;}
        public int customerID { get; set; }
        public int OrderID { get; set; }
        public Customer customer { get; set; }
        public Order order { get; set; }
    }
}
