﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace WebApplication11.Models
{
    public class Customer
    {
        public int customerID { get; set; }
        public string customerName { get; set; }
        public string CustomerEmail { get; set; }
        public int CustomerPhone { get; set; }
        [Display(Name="Image")]
        [DefaultValue("default.png")]

        public ICollection<CustomerOrder> orders { get; set; }
       


    }
}
