﻿using System;
using System.Collections.Generic;
namespace WebApplication11.Models
{
    public class Order
    {
        public int OrderID { get;set; }
        public string OrderName { get; set; }
        public string CustomerEmail { get; set; }
        public string personName { get; set; }
        public string Address { get; set; }
        public int price { get; set; }
        public ICollection<CustomerOrder> orders { get; set; }

    }
}
