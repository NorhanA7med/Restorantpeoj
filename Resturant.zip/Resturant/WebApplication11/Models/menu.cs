﻿using System;
using System.Collections.Generic;
namespace WebApplication11.Models
{
    public class menu
    {
        public int menuID {get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int price{ get; set; }
        public Category category { get; set; }
        public Offer offers { get; set; }
    }
}
