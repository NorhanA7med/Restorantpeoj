﻿using System;
using System.Collections.Generic;
namespace WebApplication11.Models
{
    public class Category
    {
       public int CategoryID { set; get; }
        public string CategoryName { set; get; }
        public ICollection<menu> menu { set; get; }
    }
}
