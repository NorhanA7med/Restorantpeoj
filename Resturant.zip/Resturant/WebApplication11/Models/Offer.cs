﻿using System;
using System.Collections.Generic;
namespace WebApplication11.Models
{
    public class Offer
    {
        public int offerID { get; set; }
        public string offerName { get; set; }
        public string offerImage { get; set; }
        public string description { get; set; }
        public int offerprice { get; set; }
        public ICollection<menu> offers { get; set; }
    }
}
