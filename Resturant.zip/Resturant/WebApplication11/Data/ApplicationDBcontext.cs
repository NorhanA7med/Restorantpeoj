﻿using WebApplication11.Models;
using Microsoft.EntityFrameworkCore;
namespace WebApplication11.Data
{
    public class ApplicationDBcontext:DbContext
    {
        public ApplicationDBcontext(DbContextOptions<ApplicationDBcontext> options) : base(options) { }

        public DbSet<Category> Categories { get; set; }
        public DbSet<ContactUs> contacts { get; set; }
        public DbSet<Customer> customers { get; set; }

        public DbSet<CustomerOrder> CustomerOrders { get; set; }
        public DbSet<menu> menus { get; set; }
        public DbSet<Offer> offers { get; set; }

        public DbSet<Order> orders { get; set; }





    }
}
