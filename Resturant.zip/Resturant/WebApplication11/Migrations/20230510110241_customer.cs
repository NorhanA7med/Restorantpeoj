﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Restuarant.Migrations
{
    /// <inheritdoc />
    public partial class customer : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_contacts_customers_customerID",
                table: "contacts");

            migrationBuilder.DropIndex(
                name: "IX_contacts_customerID",
                table: "contacts");

            migrationBuilder.DropColumn(
                name: "customerID",
                table: "contacts");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "customerID",
                table: "contacts",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_contacts_customerID",
                table: "contacts",
                column: "customerID",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_contacts_customers_customerID",
                table: "contacts",
                column: "customerID",
                principalTable: "customers",
                principalColumn: "customerID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
