﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication11.Controllers
{
    public class OffersController : Controller
    {
        public IActionResult Offer()
        {
            return View();
        }
    }
}
