﻿using Microsoft.AspNetCore.Mvc;
using WebApplication11.Data;
using WebApplication11.Models;

namespace WebApplication11.Controllers
{
    public class ContactController : Controller
    {
        private ApplicationDBcontext db;

       
        public ContactController(ApplicationDBcontext db)
        {
            this.db = db;
        }
        [HttpGet]
        
        public IActionResult contact()
        {
            return View();
        }
        [HttpPost]
        public IActionResult contact(ContactUs con)
        {
            db.contacts.Add(con);
            db.SaveChanges();
            return View();
        }
    }
}
