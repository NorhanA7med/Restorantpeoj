﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication11.Controllers
{
    public class MenuController : Controller
    {
        public IActionResult Menu()
        {
            return View();
        }
    }
}
