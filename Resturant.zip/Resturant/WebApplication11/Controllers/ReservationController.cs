﻿using Microsoft.AspNetCore.Mvc;
using WebApplication11.Data;
using WebApplication11.Models;

namespace WebApplication11.Controllers
{
    public class ReservationController : Controller
    {
        public IActionResult reserve()
        {
            return View();
        }
        ApplicationDBcontext db;
        public ReservationController(ApplicationDBcontext db)
        {
            this.db = db;
        }
        [HttpPost]
        public IActionResult reserve (Order ord)
        {
            db.orders.Add(ord);
            db.SaveChanges();
            return View();
        }

        
    }
}
