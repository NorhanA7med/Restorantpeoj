﻿using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using WebApplication11.Data;
using WebApplication11.Models;
using Microsoft.Extensions.Hosting;
namespace Restuarant.Controllers
{
    public class SignoutController : Controller
    {
        private ApplicationDBcontext db;
        private readonly IWebHostEnvironment _environement;

        public SignoutController(ApplicationDBcontext db)
        {
            this.db = db;
        }
        [HttpGet]
        public IActionResult Signout()
        {
            return View();
        }

        [HttpPost]

        [ValidateAntiForgeryToken] // to more security

        public async Task<IActionResult> Signout([Bind("customerName", " CustomerEmail", " CustomerPhone" )]Customer customer , IFormFile img_file)
        {
            // to create Images folder in the project
            string path = Path.Combine(_environement.WebRootPath ,"images"); // wwwroot Img
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
      

            /*public IActionResult Signout(Customer cus)
             {
                 db.Add(cus);
                 db.SaveChanges();
                 return View();
             }*/
            return RedirectToAction("Index");
        }
    }
}
